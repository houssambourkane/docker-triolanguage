﻿Typeface © (faldykudo). <2020>. All Rights Reserved 
kudoCreative

if you find any problem/bug on my font please just feel free to contact me 
faldy.kudo@gmail.com 
i would love to fix and help you,


To use all feature and full version please just click link:
https://www.creativefabrica.com/product/cornelia-font-duo/ref/216322/


find me on instagram @faldykudo


support and donation

https://paypal.me/FadilAbdillah

Thank you



Regad.